export enum API {
  users = 'api/users',
  activities = 'api/activities'
};