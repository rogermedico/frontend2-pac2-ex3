export enum USER_TYPES {
  tourist = 'tourist',
  company = 'company'
};