export enum NATIONALITIES {
  es = 'ES',
  fr = 'FR',
  it = 'IT',
  pt = 'PT'
};