export enum ACTIVITY_STATUS {
  cancelled = 'Cancelled',
  complete = 'Complete',
  available = 'Available'
}