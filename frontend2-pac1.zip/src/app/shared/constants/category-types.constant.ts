export enum CATEGORY_TYPES {
  cultura = 'Cultura i patrimoni',
  enoturisme = 'Enoturisme',
  platges = 'Platges'
}