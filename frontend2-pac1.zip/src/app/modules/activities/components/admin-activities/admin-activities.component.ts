import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Activity } from '@models/activity.model';
import { AppStore } from '@models/store.model';
import { User } from '@models/user.model';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import * as UserSelectors from '@store/user/user.selector';
import * as ActivitySelectors from '@store/activity/activity.selector';
import * as ActivityActions from '@store/activity/activity.action';

@Component({
  selector: 'app-admin-activities',
  templateUrl: './admin-activities.component.html',
  styleUrls: ['./admin-activities.component.css']
})
export class AdminActivitiesComponent implements OnInit {

  public title: String = 'Edit Activities';
  public user: User;
  public activities: Activity[];
  public userLoggedIn$: Observable<User> = this.store$.select(UserSelectors.selectUser);
  public activities$: Observable<Activity[]> = this.store$.select(ActivitySelectors.selectActivities);

  constructor(private store$: Store<AppStore>, private router: Router) { }

  ngOnInit(): void {

    this.userLoggedIn$.subscribe(userLoggedIn => this.user = userLoggedIn);
    this.activities$.subscribe(activities => {
      this.activities = activities.filter(ac => ac.owner === this.user.id);
    })

  }

  createActivity() {
    this.router.navigate(['/activities/admin/new']);
  }

  updateActivity(id: number) {
    this.router.navigate(['/activities/admin/edit', id]);
  }

  deleteActivity(activityId: number) {
    if (confirm('You are about to delete an activity record. Are you sure?')) {
      this.store$.dispatch(ActivityActions.ActivityDelete({ activityId: activityId }))
    }
  }

}
